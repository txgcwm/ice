# $Id: uac-ticket-1866-reinv-after-failed-nego.py 5130 2015-07-09 12:49:47Z nanang $
#
import inc_const as const

PJSUA = ["--null-audio --max-calls=1 --dis-codec=pcma --auto-answer=200"]

PJSUA_EXPECTS = []
