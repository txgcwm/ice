# $Id: uac-ticket-1864-scenario2.py 5135 2015-07-14 08:38:29Z nanang $
#
import inc_const as const

PJSUA = ["--null-audio --max-calls=1 --dis-codec=pcma --auto-answer=200"]

PJSUA_EXPECTS = []
