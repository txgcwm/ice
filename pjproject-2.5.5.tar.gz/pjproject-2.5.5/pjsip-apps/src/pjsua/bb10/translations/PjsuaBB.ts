<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>main</name>
    <message>
        <location filename="../assets/main.qml" line="11"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../assets/main.qml" line="23"/>
        <source>pjsua BB10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../assets/main.qml" line="32"/>
        <source>Starting..</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
