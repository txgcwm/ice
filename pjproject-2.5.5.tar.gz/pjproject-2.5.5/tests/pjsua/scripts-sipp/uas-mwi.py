# $Id: uas-mwi.py 4188 2012-06-29 09:01:17Z nanang $
#
import inc_const as const

PJSUA = ["--null-audio --max-calls=1 --id sip:pjsua@localhost:$SIPP_PORT --mwi"]

PJSUA_EXPECTS = []
